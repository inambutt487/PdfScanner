package me.sid.smartcropperlib;

public interface IvGenericCallback<T> {
        public void Ivcallback(T t);
    }