package me.sid.smartcropperlib;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import me.sid.smartcropperlib.utils.BitmapUtils;
import me.sid.smartcropperlib.utils.CropTransparent;
import me.sid.smartcropperlib.utils.CropUtils;
import me.sid.smartcropperlib.utils.MyCanvas;
import me.sid.smartcropperlib.utils.SizeManager;

/**
 * Created by qiulinmin on 8/1/17.
 */

public class SmartCropper {

    public static void buildImageDetector(Context context) {
        SmartCropper.buildImageDetector(context, null);
    }

    public static void buildImageDetector(Context context, String modelFile) {

    }

    /**
     * 裁剪图片
     * @param srcBmp 待裁剪图片
     * @param cropPoints 裁剪区域顶点，顶点坐标以图片大小为准
     * @return 返回裁剪后的图片
     */
    public static Bitmap crop(Bitmap srcBmp, Point[] cropPoints, Context context) {
        if (srcBmp == null || cropPoints == null) {
            throw new IllegalArgumentException("srcBmp and cropPoints cannot be null");
        }
        if (cropPoints.length != 4) {
            throw new IllegalArgumentException("The length of cropPoints must be 4 , and sort by leftTop, rightTop, rightBottom, leftBottom");
        }
        Point leftTop = cropPoints[0];
        Point rightTop = cropPoints[1];
        Point rightBottom = cropPoints[2];
        Point leftBottom = cropPoints[3];

        /*int cropWidth = (int) ((CropUtils.getPointsDistance(leftTop, rightTop)
                + CropUtils.getPointsDistance(leftBottom, rightBottom))/2);
        int cropHeight = (int) ((CropUtils.getPointsDistance(leftTop, leftBottom)
                + CropUtils.getPointsDistance(rightTop, rightBottom))/2);*/

        int cropWidth = (int) ((CropUtils.getPointsDistance(leftTop, rightTop)
                + CropUtils.getPointsDistance(leftBottom, rightBottom)));
        int cropHeight = (int) ((CropUtils.getPointsDistance(leftTop, leftBottom)
                + CropUtils.getPointsDistance(rightTop, rightBottom)));

        //Crop Canvance
        /*Bitmap cropBitmap = Bitmap.createBitmap(cropWidth, cropHeight, Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(cropBitmap);

        Rect dstRect = new Rect();
        canvas.getClipBounds(dstRect); // get canvas size base screen size

        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);

        Path path=new Path();

        path.moveTo(leftTop.x, leftTop.y);

        path.lineTo(rightTop.x, rightTop.y);
        path.lineTo(rightBottom.x, rightBottom.y);
        path.lineTo(leftBottom.x, leftBottom.y);
        path.lineTo(leftTop.x, leftTop.y);

        canvas.drawPath(path, paint);


        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(srcBmp, 0, 0, paint);*/


        /*
        canvas.drawBitmap(srcBmp, null, dstRect, paint);
        SmartCropper.nativeCrop(srcBmp, cropPoints, cropBitmap);
        return RotateBitmap(cropBitmap, 90f);*/
        /*return RotateBitmap(cropBitmap, 270f);
        */

        Bitmap background = Bitmap.createBitmap(cropWidth, cropHeight, Bitmap.Config.ARGB_8888);

        float originalWidth = srcBmp.getWidth();
        float originalHeight = srcBmp.getHeight();

        Canvas canvas = new Canvas(background);

        float scale = cropWidth / originalWidth;

        float xTranslation = 0.0f;
        float yTranslation = (cropHeight - originalHeight * scale) / 2.0f;

        Matrix transformation = new Matrix();
        transformation.postTranslate(xTranslation, yTranslation);
        transformation.preScale(scale, scale);

        Paint paint = new Paint();
        paint.setFilterBitmap(true);

        Path path=new Path();

        path.moveTo(leftTop.x, leftTop.y);

        path.lineTo(rightTop.x, rightTop.y);
        path.lineTo(rightBottom.x, rightBottom.y);
        path.lineTo(leftBottom.x, leftBottom.y);
        path.lineTo(leftTop.x, leftTop.y);

        canvas.drawPath(path, paint);

        canvas.drawBitmap(srcBmp, transformation, paint);

        return background;
    }




    public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap
                .getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        final RectF rectF = new RectF(rect);
        final float roundPx = pixels;

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);

        return output;
    }



    public static Bitmap AlphaToBlack(Bitmap image) {
        Bitmap rgbImage = image.copy(Bitmap.Config.ARGB_8888, true);

        for (int y = 0; y < rgbImage.getHeight(); y++) {
            for (int x = 0; x < rgbImage.getWidth(); x++) {
                int aPixel = rgbImage.getPixel(x, y);
                if (rgbImage.getPixel(x, y) < 0xFF000000)
                    rgbImage.setPixel(x, y,  0xFF000000);
            }
        }
        return rgbImage;
    }


    public static Bitmap scaleAndGenerateBmpWithNewSize(Bitmap src, SizeManager newSize) {
        Bitmap bitmapRes;
        int imageWidth = src.getWidth();
        int imageHeight = src.getHeight();

        float newWidth = newSize.width;
        float scaleFactor = newWidth / imageWidth;
        int newHeight = (int) (imageHeight * scaleFactor);
        bitmapRes = Bitmap.createScaledBitmap(src, (int) newWidth, newHeight, true);
        bitmapRes = Bitmap.createBitmap(bitmapRes, 0, 0, (int) newWidth, (int) newSize.height);
        return bitmapRes;
    }

    public  static Bitmap RotateBitmap(Bitmap source, float angle)
    {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }




}
